More at
http://ajaxload.info/